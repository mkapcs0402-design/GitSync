pub mod gitea;
pub mod github;
pub mod https;
pub mod ssh;
